HAPPY BIRTHDAY DISHA — how to edit

1. REPLACE PHOTOS
   Just overwrite the files in assets/images/ — keep the same names:
   - profile.jpg           → the circular profile photo
   - photo01.jpg – photo10.jpg  → used in the "Little Moments" section on Home
   - photo01.jpg – photo30.jpg  → also reused for the Gallery page (30 photos)
   - photo01.jpg – photo40.jpg  → all placeholders are pre-generated so you have
                                   room to add up to 40 if you extend galleryCount

2. REPLACE MUSIC
   Overwrite assets/music/birthday-music.mp3 with your own track (same filename).
   The current file is just a 3-second placeholder tone.

3. EDIT TEXT / STORIES / NOTES
   Open script.js and look at the CONTENT object at the very top.
   - targetDate       → change the countdown target (year, month is 0-indexed, day, hour, minute)
   - profileNotes     → the 10 captions under "Little Moments"
   - galleryCount     → how many photos show on the Gallery page
   - stories          → the Golpo page cards (title / preview / full body)
   - pinNotes         → the messages on the pin board

4. RUN IT
   Open index.html directly in a browser, or serve the folder with any static
   file server (e.g. `python3 -m http.server`) for the smoothest experience.

Everything else (index.html, style.css) drives the animations and layout and
shouldn't need touching unless you want to change the design itself.
